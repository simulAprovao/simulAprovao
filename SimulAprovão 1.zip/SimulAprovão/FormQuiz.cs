﻿/*
 * Created by SharpDevelop.
 * User: Aluno
 * Date: 29/09/2025
 * Time: 15:02
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace SimulAprovão
{
	/// <summary>
	/// Description of Quiz.
	/// </summary>
	public partial class FormQuiz : Form
	{
		string nomeUsuario;
		public FormQuiz(string nome)
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			BtnPergunta1Click(null, EventArgs.Empty);
			this.Load += new EventHandler(FormQuiz_Load);
			nomeUsuario = nome;
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}	
			
		//variáveis gerais
		string alternativaCorreta = "X";
		int pontos = 0;	
		int numeroQuestaoAtual = 0;	
		
		private DateTime inicioQuiz;
		private TimeSpan tempoDecorrido;	

		private void FormQuiz_Load(object sender, EventArgs e){
			inicioQuiz = DateTime.Now;
			timerQuiz.Start();
			lblTimer.Text = "00:00:00";
		}
		
		void BtnAlternativaAClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "A"){
				MessageBox.Show("✅ Questão " + numeroQuestaoAtual + " - ACERTOU!");
				pontos++;
				lblPontos.Text = "Pontos: " + pontos;
			}
			
			else {
				MessageBox.Show("❌ Questão " + numeroQuestaoAtual + " - ERROU!\nResposta correta: " + alternativaCorreta);
			}
			
			panel1.Enabled = false;			
		}
		
		void BtnAlternativaBClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "B"){
				MessageBox.Show("✅ Questão " + numeroQuestaoAtual + " - ACERTOU!");
				pontos++;
				lblPontos.Text = "Pontos: " + pontos;
			}
			
			else {
				MessageBox.Show("❌ Questão " + numeroQuestaoAtual + " - ERROU!\nResposta correta: " + alternativaCorreta);
			}
			
			panel1.Enabled = false;			
		}
		
		void BtnAlternativaCClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "C"){
				MessageBox.Show("✅ Questão " + numeroQuestaoAtual + " - ACERTOU!");
				pontos++;
				lblPontos.Text = "Pontos: " + pontos;
			}
			
			else {
				MessageBox.Show("❌ Questão " + numeroQuestaoAtual + " - ERROU!\nResposta correta: " + alternativaCorreta);
			}
			
			panel1.Enabled = false;					
		}
		
		void BtnAlternativaDClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "D"){
				MessageBox.Show("✅ Questão " + numeroQuestaoAtual + " - ACERTOU!");
				pontos++;
				lblPontos.Text = "Pontos: " + pontos;
			}
			
			else {
				MessageBox.Show("❌ Questão " + numeroQuestaoAtual + " - ERROU!\nResposta correta: " + alternativaCorreta);
			}
			
			panel1.Enabled = false;				
		}
		
		void BtnAlternativaEClick(object sender, EventArgs e)
		{
			if (alternativaCorreta == "E"){
				MessageBox.Show("✅ Questão " + numeroQuestaoAtual + " - ACERTOU!");
				pontos++;
				lblPontos.Text = "Pontos: " + pontos;
			}
			
			else {
				MessageBox.Show("❌ Questão " + numeroQuestaoAtual + " - ERROU!\nResposta correta: " + alternativaCorreta);
			}
			
			panel1.Enabled = false;					
		}
		
		void BtnPergunta1Click(object sender, EventArgs e)
		{
			
			numeroQuestaoAtual = 1;
			
			lblPergunta.Text = "Leia o texto: Nem sempre o silêncio é falta de resposta. Às vezes, ele é a forma mais sábia de mostrar que certas perguntas não merecem palavras.";
			lblTextoA.Text = "O silêncio é sempre sinal de fraqueza.";
			lblTextoB.Text = "As palavras são inúteis em qualquer situação.";
			lblTextoC.Text = "O silêncio pode ser uma forma de sabedoria e resposta.";
			lblTextoD.Text = "As pessoas devem evitar o diálogo.";
			lblTextoE.Text = "O silêncio impede o aprendizado.";			
			alternativaCorreta = "C";

			panel1.Enabled = false;
			btnPergunta1.Enabled = false;
			btnPergunta2.Enabled = true;				
		}
		
		void BtnPergunta2Click(object sender, EventArgs e)
		{
			
			numeroQuestaoAtual = 2;
			
			lblPergunta.Text = "Leia o trecho: As redes sociais nos conectam com o mundo, mas às vezes nos afastam de quem está ao nosso lado. O autor faz uso de um contraste para:";
			lblTextoA.Text = "Criticar a tecnologia como um todo.";
			lblTextoB.Text = "Mostrar a contradição entre conexão virtual e distância real.";
			lblTextoC.Text = "Defender o uso excessivo das redes sociais.";
			lblTextoD.Text = "Explicar como funcionam os aplicativos de mensagens.";	
			lblTextoE.Text = "Incentivar a comunicação apenas presencial.";
			alternativaCorreta = "B";

			panel1.Enabled = true;
			btnPergunta1.Enabled = false;
			btnPergunta2.Enabled = false;
			btnPergunta3.Enabled = true;				
		}
		
		void BtnPergunta3Click(object sender, EventArgs e)
		{
			
			numeroQuestaoAtual = 3;
			
			lblPergunta.Text = "Leia a situação: Um grupo de amigos dividiu igualmente uma conta de R$ 180,00 entre 6 pessoas. Depois, uma delas foi embora sem pagar. Os outros decidiram dividir o valor total novamente entre os 5 que ficaram. Cada um dos 5 amigos pagará:";
			lblTextoA.Text = "R$ 25,00";
			lblTextoB.Text = "R$ 30,00";
			lblTextoC.Text = "R$ 35,00";
			lblTextoD.Text = "R$ 36,00";	
			lblTextoE.Text = "R$ 40,00";
			alternativaCorreta = "E";

			panel1.Enabled = true;
			btnPergunta1.Enabled = false;
			btnPergunta2.Enabled = false;
			btnPergunta3.Enabled = false;
			btnPergunta4.Enabled = true;				
		}
		
		void BtnPergunta4Click(object sender, EventArgs e)
		{
			
			numeroQuestaoAtual = 4;
			
			lblPergunta.Text = "Leia o fragmento: Durante o século XIX, o trabalho escravizado sustentou grande parte da economia brasileira. Mesmo após a abolição, em 1888, os ex-escravizados não tiveram acesso à terra nem a direitos básicos. O texto destaca:";
			lblTextoA.Text = "A rápida integração dos ex-escravizados à sociedade.";
			lblTextoB.Text = "O processo de inclusão social após a abolição";
			lblTextoC.Text = "A continuidade das desigualdades após o fim da escravidão.";
			lblTextoD.Text = "O avanço econômico dos libertos após 1888.";
			lblTextoE.Text = "O abandono da agricultura após o fim da escravidão.";			
			alternativaCorreta = "C";

			panel1.Enabled = true;
			btnPergunta1.Enabled = false;
			btnPergunta2.Enabled = false;
			btnPergunta3.Enabled = false;
			btnPergunta4.Enabled = false;
			btnPergunta5.Enabled = true;					
		}
		
		void BtnPergunta5Click(object sender, EventArgs e)
		{
			
			numeroQuestaoAtual = 5;
			
			lblPergunta.Text = "Leia o trecho: As cidades crescem rapidamente, mas nem sempre esse crescimento é planejado. O resultado é o aumento da desigualdade urbana. O texto indica que:";
			lblTextoA.Text = "O crescimento urbano sempre melhora a qualidade de vida.";
			lblTextoB.Text = "A expansão das cidades ocorre de forma totalmente organizada.";
			lblTextoC.Text = "O crescimento urbano desordenado gera problemas sociais.";
			lblTextoD.Text = "O planejamento urbano é um problema apenas rural.";
			lblTextoE.Text = "As desigualdades não estão relacionadas ao espaço urbano.";			
			alternativaCorreta = "C";

			panel1.Enabled = true;
			btnPergunta1.Enabled = false;
			btnPergunta2.Enabled = false;
			btnPergunta3.Enabled = false;
			btnPergunta4.Enabled = false;
			btnPergunta5.Enabled = false;	
			btnPergunta6.Enabled = true;			
		}
		
		void BtnPergunta6Click(object sender, EventArgs e)
		{
			
			numeroQuestaoAtual = 6;
			
			lblPergunta.Text = "Leia: Os pulmões são órgãos que realizam trocas gasosas com o ambiente. Esse processo é essencial para que o oxigênio chegue às células e o gás carbônico seja eliminado. O texto descreve a função de qual sistema?";
			lblTextoA.Text = "Digestório.";
			lblTextoB.Text = "Circulatório.";
			lblTextoC.Text = "Respiratório.";
			lblTextoD.Text = "Nervoso.";
			lblTextoE.Text = "Endócrino";			
			alternativaCorreta = "C";

			panel1.Enabled = true;
			btnPergunta1.Enabled = false;
			btnPergunta2.Enabled = false;
			btnPergunta3.Enabled = false;
			btnPergunta4.Enabled = false;
			btnPergunta5.Enabled = false;
			btnPergunta6.Enabled = false;
			btnPergunta7.Enabled = true;			
		}
		
		void BtnPergunta7Click(object sender, EventArgs e)
		{
			
			numeroQuestaoAtual = 7;
			
			lblPergunta.Text = "Leia a situação: Ao abrir uma garrafa de refrigerante, observa-se a liberação de gás. Esse fenômeno ocorre porque, ao diminuir a pressão, o gás carbônico dissolvido escapa para o ambiente. A situação descrita envolve o conceito de:";
			lblTextoA.Text = "Combustão.";
			lblTextoB.Text = "Evaporação.";
			lblTextoC.Text = "Solubilidade e pressão";
			lblTextoD.Text = "Fusão.";
			lblTextoE.Text = "Neutralização.";			
			alternativaCorreta = "C";

			panel1.Enabled = true;
			btnPergunta1.Enabled = false;
			btnPergunta2.Enabled = false;
			btnPergunta3.Enabled = false;
			btnPergunta4.Enabled = false;
			btnPergunta5.Enabled = false;
			btnPergunta6.Enabled = false;
			btnPergunta7.Enabled = false;
			btnPergunta8.Enabled = true;			
		}
		
		void BtnPergunta8Click(object sender, EventArgs e)
		{
			
			numeroQuestaoAtual = 8;
			
			lblPergunta.Text = "Leia o texto: As queimadas na Amazônia afetam o clima global e ameaçam espécies únicas. A destruição da floresta impacta não só o Brasil, mas todo o planeta. O autor quer destacar que:";
			lblTextoA.Text = "O problema é apenas local.";
			lblTextoB.Text = "A floresta não influencia o equilíbrio climático.";
			lblTextoC.Text = "A Amazônia tem importância ecológica mundial.";
			lblTextoD.Text = "As queimadas não afetam o meio ambiente.";
			lblTextoE.Text = "O desmatamento traz benefícios econômicos apenas.";			
			alternativaCorreta = "C";

			panel1.Enabled = true;
			btnPergunta1.Enabled = false;
			btnPergunta2.Enabled = false;
			btnPergunta3.Enabled = false;
			btnPergunta4.Enabled = false;
			btnPergunta5.Enabled = false;
			btnPergunta6.Enabled = false;
			btnPergunta7.Enabled = false;
			btnPergunta8.Enabled = false;
			btnPergunta9.Enabled = true;			
		}
		
		void BtnPergunta9Click(object sender, EventArgs e)
		{
			
			numeroQuestaoAtual = 9;
			
			lblPergunta.Text = "Leia: O comportamento humano é influenciado pela cultura, que define o que é considerado certo ou errado em cada sociedade. O texto defende que:";
			lblTextoA.Text = "A moral é idêntica em todos os lugares.";
			lblTextoB.Text = "A cultura molda os valores e comportamentos sociais.";
			lblTextoC.Text = "A genética define o comportamento humano.";
			lblTextoD.Text = "As regras sociais são universais.";
			lblTextoE.Text = "As culturas não influenciam o indivíduo.";			
			alternativaCorreta = "B";

			panel1.Enabled = true;
			btnPergunta1.Enabled = false;
			btnPergunta2.Enabled = false;
			btnPergunta3.Enabled = false;
			btnPergunta4.Enabled = false;
			btnPergunta5.Enabled = false;
			btnPergunta6.Enabled = false;
			btnPergunta7.Enabled = false;
			btnPergunta9.Enabled = false;
			btnPergunta10.Enabled = true;			
		}
		
		void BtnPergunta10Click(object sender, EventArgs e)
		{
			
			numeroQuestaoAtual = 10;
			
			lblPergunta.Text = "Read the text: When I was a child, I used to dream about being a teacher. Now that I am one, I realize that teaching is not only about sharing knowledge, but also about learning from my students. The main idea of the text is that:";
			lblTextoA.Text = "Teaching is a one-way process.";
			lblTextoB.Text = "Teachers stop learning after finishing school.";
			lblTextoC.Text = "Teaching involves both teaching and learning.";
			lblTextoD.Text = "Students know more than teachers.";
			lblTextoE.Text = "The author regrets becoming a teacher.";			
			alternativaCorreta = "C";

			panel1.Enabled = true;
			btnPergunta1.Enabled = false;
			btnPergunta2.Enabled = false;
			btnPergunta3.Enabled = false;
			btnPergunta4.Enabled = false;
			btnPergunta5.Enabled = false;
			btnPergunta6.Enabled = false;
			btnPergunta7.Enabled = false;
			btnPergunta8.Enabled = false;
			btnPergunta9.Enabled = false;
			btnPergunta10.Enabled = false;			
		}
		
		void BtnPaginaInicialClick(object sender, EventArgs e)
		{
			FormHome home = new FormHome(nomeUsuario);
			home.Show();
			this.Hide();			
		}
		
		void BtnReiniciarClick(object sender, EventArgs e)
		{
			// Resetar todas as variáveis
			   numeroQuestaoAtual = 0;
			   pontos = 0;
			   lblPontos.Text = "Pontos: 0";
			   
			   // Reativar todos os botões de questão
			   btnPergunta1.Enabled = true;
			   btnPergunta2.Enabled = true;
			   btnPergunta3.Enabled = true;
			   btnPergunta4.Enabled = true;
			   btnPergunta5.Enabled = true;
			   btnPergunta6.Enabled = true;
			   btnPergunta7.Enabled = true;
			   btnPergunta8.Enabled = true;
			   btnPergunta9.Enabled = true;
			   btnPergunta10.Enabled = true;
			   
			   // Reativar o panel das alternativas
			   panel1.Enabled = true;
			   // Limpar a pergunta atual
			   lblPergunta.Text = "Clique em uma questão para começar!";
			   lblTextoA.Text = "A";
			   lblTextoB.Text = "B";
			   lblTextoC.Text = "C";
			   lblTextoD.Text = "D";
			   lblTextoE.Text = "E";
			   MessageBox.Show("Quiz reiniciado! Clique na Questão 1 para começar novamente.");
		}
		
		void TimerQuizTick(object sender, EventArgs e)
		{
			tempoDecorrido = DateTime.Now - inicioQuiz;
			lblTimer.Text = tempoDecorrido.ToString(@"hh\:mm\:ss");			
		}
		
		void SalvarPontuacao(){
			string caminhoArquivo = "ranking.txt";
			if (nomeUsuario == "" || pontos == 0){
				MessageBox.Show("Informações vazias.");
			} else {
				using (StreamWriter sw = File.AppendText(caminhoArquivo)){
					sw.WriteLine(nomeUsuario + ";" + pontos);
				}
				MessageBox.Show("Pontuação cadastrada com sucesso.");
			}
		}
		
		void BtnFinalizarClick(object sender, EventArgs e)
		{
			timerQuiz.Stop();
			
			// Calcular porcentagem de acertos
			double porcentagem = (pontos / 10.0) * 100;
			
			// Resultado final
			string mensagem = string.Format("📊 RESULTADO FINAL 📊\n\n" +
			          "✅ Questões acertadas: {0} de 10\n" +
			          "📈 Porcentagem: {1:F1}%\n" +
			          "⏰ Tempo total: {2}\n\n",
			          pontos, porcentagem, lblTimer.Text);
			
			// Mensagem personalizada baseada no desempenho
   			if (pontos >= 9)
  			{
       			mensagem += "🎉 EXCELENTE! Você dominou o conteúdo!";
   			}
   			
   			else if (pontos >= 7)
   			{
       			mensagem += "👍 MUITO BOM! Desempenho acima da média!";
   			}
   			
   			else if (pontos >= 5)
   			{
       			mensagem += "💪 BOM! Continue estudando para melhorar!";
   			}
   			
   			else
  			{
       			mensagem += "📚 ESTUDE MAIS! Revise o conteúdo e tente novamente!";
   			}
   			
   			SalvarPontuacao();
   			
   			MessageBox.Show(mensagem, "Quiz Finalizado!", MessageBoxButtons.OK, MessageBoxIcon.Information);
   			
   			// Opcional: perguntar se quer reiniciar
   			DialogResult resultado = MessageBox.Show("Deseja reiniciar o quiz?", "Reiniciar",
                                          MessageBoxButtons.YesNo, MessageBoxIcon.Question);
   			if (resultado == DialogResult.Yes)
   			{
       			BtnReiniciarClick(sender, e); // Chama o método de reiniciar que você já tem
   			}
		}
	}
}