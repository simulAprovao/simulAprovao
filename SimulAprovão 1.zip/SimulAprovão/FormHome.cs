﻿/*
 * Created by SharpDevelop.
 * User: Aluno
 * Date: 29/09/2025
 * Time: 13:18
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace SimulAprovão
{
	/// <summary>
	/// Description of Form1.
	/// </summary>
	public partial class FormHome : Form
	{
		string nomeUsuario;
		public FormHome(string nome)
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			nomeUsuario = nome;
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void FotoPerfilClick(object sender, EventArgs e)
		{
			FormPerfil perfil = new FormPerfil("Aluno");
			perfil.Show();
			this.Hide();
		}
		
		
		void FotoQuizClick(object sender, EventArgs e)
		{
			FormQuiz quiz = new FormQuiz(nomeUsuario);
			quiz.Show();
			this.Hide();
		}
		
		void FotoRankingClick(object sender, EventArgs e)
		{
			FormRanking ranking = new FormRanking(nomeUsuario);
			ranking.Show();
			this.Hide();
		}
	}
}
