﻿/*
 * Created by SharpDevelop.
 * User: Aluno
 * Date: 29/09/2025
 * Time: 14:20
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace SimulAprovão
{
   partial class FormPerfil
   {
       private System.ComponentModel.IContainer components = null;
       private System.Windows.Forms.Panel panel1;
       private System.Windows.Forms.Label label1;
       private System.Windows.Forms.PictureBox pictureBox1;
       private System.Windows.Forms.Label lblUsuario;
       private System.Windows.Forms.Label lblSenha;
       private System.Windows.Forms.Button btnSairdoPerfil;
       private System.Windows.Forms.TextBox txtNome;
       private System.Windows.Forms.TextBox txtSenha;
       private System.Windows.Forms.Button btnSalvar;
       private System.Windows.Forms.Label lblNovaSenha;
       private System.Windows.Forms.TextBox txtNovaSenha;
       private System.Windows.Forms.Label lblConfirmarSenha;
       private System.Windows.Forms.TextBox txtConfirmarSenha;
       protected override void Dispose(bool disposing)
       {
           if (disposing) {
               if (components != null) {
                   components.Dispose();
               }
           }
           base.Dispose(disposing);
       }
       private void InitializeComponent()
       {
       	System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPerfil));
       	this.panel1 = new System.Windows.Forms.Panel();
       	this.pictureBox1 = new System.Windows.Forms.PictureBox();
       	this.label1 = new System.Windows.Forms.Label();
       	this.lblUsuario = new System.Windows.Forms.Label();
       	this.lblSenha = new System.Windows.Forms.Label();
       	this.btnSairdoPerfil = new System.Windows.Forms.Button();
       	this.txtNome = new System.Windows.Forms.TextBox();
       	this.txtSenha = new System.Windows.Forms.TextBox();
       	this.btnSalvar = new System.Windows.Forms.Button();
       	this.lblNovaSenha = new System.Windows.Forms.Label();
       	this.txtNovaSenha = new System.Windows.Forms.TextBox();
       	this.lblConfirmarSenha = new System.Windows.Forms.Label();
       	this.txtConfirmarSenha = new System.Windows.Forms.TextBox();
       	this.panel1.SuspendLayout();
       	((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
       	this.SuspendLayout();
       	// 
       	// panel1
       	// 
       	this.panel1.BackColor = System.Drawing.Color.CornflowerBlue;
       	this.panel1.Controls.Add(this.pictureBox1);
       	this.panel1.Controls.Add(this.label1);
       	this.panel1.Location = new System.Drawing.Point(0, 0);
       	this.panel1.Margin = new System.Windows.Forms.Padding(2);
       	this.panel1.Name = "panel1";
       	this.panel1.Size = new System.Drawing.Size(493, 71);
       	this.panel1.TabIndex = 0;
       	// 
       	// pictureBox1
       	// 
       	this.pictureBox1 = new System.Windows.Forms.PictureBox();
       	this.pictureBox1.Location = new System.Drawing.Point(0, -25);
       	this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
       	this.pictureBox1.Name = "pictureBox1";
       	this.pictureBox1.Size = new System.Drawing.Size(106, 123);
       	this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
       	this.pictureBox1.TabIndex = 0;
       	this.pictureBox1.TabStop = false;
       	
       	string caminhoImagem = "Image.png";
       	if (System.IO.File.Exists(caminhoImagem))
       	{
       		this.pictureBox1.Image = System.Drawing.Image.FromFile(caminhoImagem);
       	}
       	// 
       	// label1
       	// 
       	this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold);
       	this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
       	this.label1.Location = new System.Drawing.Point(201, 21);
       	this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
       	this.label1.Name = "label1";
       	this.label1.Size = new System.Drawing.Size(151, 30);
       	this.label1.TabIndex = 1;
       	this.label1.Text = "PERFIL";
       	// 
       	// lblUsuario
       	// 
       	this.lblUsuario.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
       	this.lblUsuario.ForeColor = System.Drawing.Color.CornflowerBlue;
       	this.lblUsuario.Location = new System.Drawing.Point(97, 141);
       	this.lblUsuario.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
       	this.lblUsuario.Name = "lblUsuario";
       	this.lblUsuario.Size = new System.Drawing.Size(116, 23);
       	this.lblUsuario.TabIndex = 1;
       	this.lblUsuario.Text = "Usuário:";
       	// 
       	// lblSenha
       	// 
       	this.lblSenha.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
       	this.lblSenha.ForeColor = System.Drawing.Color.CornflowerBlue;
       	this.lblSenha.Location = new System.Drawing.Point(99, 185);
       	this.lblSenha.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
       	this.lblSenha.Name = "lblSenha";
       	this.lblSenha.Size = new System.Drawing.Size(88, 28);
       	this.lblSenha.TabIndex = 4;
       	this.lblSenha.Text = "Senha:";
       	// 
       	// btnSairdoPerfil
       	// 
       	this.btnSairdoPerfil.BackColor = System.Drawing.SystemColors.ButtonHighlight;
       	this.btnSairdoPerfil.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
       	this.btnSairdoPerfil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
       	this.btnSairdoPerfil.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
       	this.btnSairdoPerfil.ForeColor = System.Drawing.Color.CornflowerBlue;
       	this.btnSairdoPerfil.Location = new System.Drawing.Point(187, 420);
       	this.btnSairdoPerfil.Margin = new System.Windows.Forms.Padding(2);
       	this.btnSairdoPerfil.Name = "btnSairdoPerfil";
       	this.btnSairdoPerfil.Size = new System.Drawing.Size(110, 45);
       	this.btnSairdoPerfil.TabIndex = 6;
       	this.btnSairdoPerfil.Text = "Sair do Perfil";
       	this.btnSairdoPerfil.UseVisualStyleBackColor = false;
       	this.btnSairdoPerfil.Click += new System.EventHandler(this.Button2Click);
       	// 
       	// txtNome
       	// 
       	this.txtNome.Location = new System.Drawing.Point(217, 146);
       	this.txtNome.Margin = new System.Windows.Forms.Padding(2);
       	this.txtNome.Name = "txtNome";
       	this.txtNome.Size = new System.Drawing.Size(176, 20);
       	this.txtNome.TabIndex = 7;
       	// 
       	// txtSenha
       	// 
       	this.txtSenha.Location = new System.Drawing.Point(217, 189);
       	this.txtSenha.Margin = new System.Windows.Forms.Padding(2);
       	this.txtSenha.Name = "txtSenha";
       	this.txtSenha.Size = new System.Drawing.Size(176, 20);
       	this.txtSenha.TabIndex = 10;
       	this.txtSenha.UseSystemPasswordChar = true;
       	// 
       	// btnSalvar
       	// 
       	this.btnSalvar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
       	this.btnSalvar.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
       	this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
       	this.btnSalvar.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
       	this.btnSalvar.ForeColor = System.Drawing.Color.CornflowerBlue;
       	this.btnSalvar.Location = new System.Drawing.Point(99, 350);
       	this.btnSalvar.Margin = new System.Windows.Forms.Padding(2);
       	this.btnSalvar.Name = "btnSalvar";
       	this.btnSalvar.Size = new System.Drawing.Size(294, 45);
       	this.btnSalvar.TabIndex = 11;
       	this.btnSalvar.Text = "Salvar Alterações";
       	this.btnSalvar.UseVisualStyleBackColor = false;
       	this.btnSalvar.Click += new System.EventHandler(this.BtnSalvarClick);
       	// 
       	// lblNovaSenha
       	// 
       	this.lblNovaSenha.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
       	this.lblNovaSenha.ForeColor = System.Drawing.Color.CornflowerBlue;
       	this.lblNovaSenha.Location = new System.Drawing.Point(97, 230);
       	this.lblNovaSenha.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
       	this.lblNovaSenha.Name = "lblNovaSenha";
       	this.lblNovaSenha.Size = new System.Drawing.Size(116, 23);
       	this.lblNovaSenha.TabIndex = 12;
       	this.lblNovaSenha.Text = "Nova Senha:";
       	// 
       	// txtNovaSenha
       	// 
       	this.txtNovaSenha.Location = new System.Drawing.Point(217, 235);
       	this.txtNovaSenha.Margin = new System.Windows.Forms.Padding(2);
       	this.txtNovaSenha.Name = "txtNovaSenha";
       	this.txtNovaSenha.Size = new System.Drawing.Size(176, 20);
       	this.txtNovaSenha.TabIndex = 13;
       	this.txtNovaSenha.UseSystemPasswordChar = true;
       	// 
       	// lblConfirmarSenha
       	// 
       	this.lblConfirmarSenha.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
       	this.lblConfirmarSenha.ForeColor = System.Drawing.Color.CornflowerBlue;
       	this.lblConfirmarSenha.Location = new System.Drawing.Point(97, 275);
       	this.lblConfirmarSenha.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
       	this.lblConfirmarSenha.Name = "lblConfirmarSenha";
       	this.lblConfirmarSenha.Size = new System.Drawing.Size(116, 23);
       	this.lblConfirmarSenha.TabIndex = 14;
       	this.lblConfirmarSenha.Text = "Confirmar:";
       	// 
       	// txtConfirmarSenha
       	// 
       	this.txtConfirmarSenha.Location = new System.Drawing.Point(217, 280);
       	this.txtConfirmarSenha.Margin = new System.Windows.Forms.Padding(2);
       	this.txtConfirmarSenha.Name = "txtConfirmarSenha";
       	this.txtConfirmarSenha.Size = new System.Drawing.Size(176, 20);
       	this.txtConfirmarSenha.TabIndex = 15;
       	this.txtConfirmarSenha.UseSystemPasswordChar = true;
       	// 
       	// FormPerfil
       	// 
       	this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
       	this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
       	this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
       	this.ClientSize = new System.Drawing.Size(490, 500);
       	this.Controls.Add(this.txtConfirmarSenha);
       	this.Controls.Add(this.lblConfirmarSenha);
       	this.Controls.Add(this.txtNovaSenha);
       	this.Controls.Add(this.lblNovaSenha);
       	this.Controls.Add(this.btnSalvar);
       	this.Controls.Add(this.txtSenha);
       	this.Controls.Add(this.txtNome);
       	this.Controls.Add(this.btnSairdoPerfil);
       	this.Controls.Add(this.lblSenha);
       	this.Controls.Add(this.lblUsuario);
       	this.Controls.Add(this.panel1);
       	this.Margin = new System.Windows.Forms.Padding(2);
       	this.Name = "FormPerfil";
       	this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
       	this.Text = "Perfil";
       	this.panel1.ResumeLayout(false);
       	((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
       	this.ResumeLayout(false);
       	this.PerformLayout();
       }
   }
}