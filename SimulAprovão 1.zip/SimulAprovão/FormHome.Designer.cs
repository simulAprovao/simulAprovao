﻿/*
 * Created by SharpDevelop.
 * User: Aluno
 * Date: 29/09/2025
 * Time: 13:18
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace SimulAprovão
{
	partial class FormHome
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormHome));
			this.panel1 = new System.Windows.Forms.Panel();
			this.FotoLogo = new System.Windows.Forms.PictureBox();
			this.lblHome = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.lblRanking = new System.Windows.Forms.Label();
			this.lblQuiz = new System.Windows.Forms.Label();
			this.lblPerfil = new System.Windows.Forms.Label();
			this.FotoRanking = new System.Windows.Forms.PictureBox();
			this.FotoQuiz = new System.Windows.Forms.PictureBox();
			this.FotoPerfil = new System.Windows.Forms.PictureBox();
			this.lblDica = new System.Windows.Forms.Label();
			this.lblTextoDica = new System.Windows.Forms.Label();
			this.lblTextoLinguagens = new System.Windows.Forms.Label();
			this.lblTextoMatematica = new System.Windows.Forms.Label();
			this.lblTextoCienciasNatureza = new System.Windows.Forms.Label();
			this.lblCienciasNatureza = new System.Windows.Forms.Label();
			this.lblLinguagens = new System.Windows.Forms.Label();
			this.lblMatematica = new System.Windows.Forms.Label();
			this.lblCienciasHumanas = new System.Windows.Forms.Label();
			this.lblTextoCienciasHumanas = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.FotoLogo)).BeginInit();
			this.panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.FotoRanking)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.FotoQuiz)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.FotoPerfil)).BeginInit();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.CornflowerBlue;
			this.panel1.Controls.Add(this.FotoLogo);
			this.panel1.Controls.Add(this.lblHome);
			this.panel1.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.panel1.Location = new System.Drawing.Point(2, -17);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(762, 126);
			this.panel1.TabIndex = 0;
			// 
			// FotoLogo
			// 
			this.FotoLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.FotoLogo.Image = ((System.Drawing.Image)(resources.GetObject("FotoLogo.Image")));
			this.FotoLogo.Location = new System.Drawing.Point(3, 0);
			this.FotoLogo.Name = "FotoLogo";
			this.FotoLogo.Size = new System.Drawing.Size(144, 142);
			this.FotoLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.FotoLogo.TabIndex = 1;
			this.FotoLogo.TabStop = false;
			// 
			// lblHome
			// 
			this.lblHome.Font = new System.Drawing.Font("Microsoft YaHei UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblHome.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
			this.lblHome.Location = new System.Drawing.Point(154, 45);
			this.lblHome.Name = "lblHome";
			this.lblHome.Size = new System.Drawing.Size(222, 57);
			this.lblHome.TabIndex = 0;
			this.lblHome.Text = "HOME";
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
			this.panel2.Controls.Add(this.lblRanking);
			this.panel2.Controls.Add(this.lblQuiz);
			this.panel2.Controls.Add(this.lblPerfil);
			this.panel2.Controls.Add(this.FotoRanking);
			this.panel2.Controls.Add(this.FotoQuiz);
			this.panel2.Controls.Add(this.FotoPerfil);
			this.panel2.Location = new System.Drawing.Point(2, 109);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(148, 574);
			this.panel2.TabIndex = 1;
			// 
			// lblRanking
			// 
			this.lblRanking.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblRanking.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.lblRanking.Location = new System.Drawing.Point(34, 432);
			this.lblRanking.Name = "lblRanking";
			this.lblRanking.Size = new System.Drawing.Size(86, 25);
			this.lblRanking.TabIndex = 5;
			this.lblRanking.Text = "Ranking";
			// 
			// lblQuiz
			// 
			this.lblQuiz.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblQuiz.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.lblQuiz.Location = new System.Drawing.Point(50, 300);
			this.lblQuiz.Name = "lblQuiz";
			this.lblQuiz.Size = new System.Drawing.Size(51, 25);
			this.lblQuiz.TabIndex = 4;
			this.lblQuiz.Text = "Quiz";
			// 
			// lblPerfil
			// 
			this.lblPerfil.Font = new System.Drawing.Font("Microsoft YaHei UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPerfil.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.lblPerfil.Location = new System.Drawing.Point(46, 163);
			this.lblPerfil.Name = "lblPerfil";
			this.lblPerfil.Size = new System.Drawing.Size(82, 25);
			this.lblPerfil.TabIndex = 3;
			this.lblPerfil.Text = "Perfil";
			// 
			// FotoRanking
			// 
			this.FotoRanking.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.FotoRanking.Image = ((System.Drawing.Image)(resources.GetObject("FotoRanking.Image")));
			this.FotoRanking.Location = new System.Drawing.Point(12, 351);
			this.FotoRanking.Name = "FotoRanking";
			this.FotoRanking.Size = new System.Drawing.Size(120, 82);
			this.FotoRanking.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.FotoRanking.TabIndex = 2;
			this.FotoRanking.TabStop = false;
			this.FotoRanking.Click += new System.EventHandler(this.FotoRankingClick);
			// 
			// FotoQuiz
			// 
			this.FotoQuiz.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.FotoQuiz.Image = ((System.Drawing.Image)(resources.GetObject("FotoQuiz.Image")));
			this.FotoQuiz.Location = new System.Drawing.Point(12, 220);
			this.FotoQuiz.Name = "FotoQuiz";
			this.FotoQuiz.Size = new System.Drawing.Size(117, 77);
			this.FotoQuiz.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.FotoQuiz.TabIndex = 1;
			this.FotoQuiz.TabStop = false;
			this.FotoQuiz.Click += new System.EventHandler(this.FotoQuizClick);
			// 
			// FotoPerfil
			// 
			this.FotoPerfil.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.FotoPerfil.Image = ((System.Drawing.Image)(resources.GetObject("FotoPerfil.Image")));
			this.FotoPerfil.Location = new System.Drawing.Point(15, 91);
			this.FotoPerfil.Name = "FotoPerfil";
			this.FotoPerfil.Size = new System.Drawing.Size(114, 69);
			this.FotoPerfil.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.FotoPerfil.TabIndex = 0;
			this.FotoPerfil.TabStop = false;
			this.FotoPerfil.Click += new System.EventHandler(this.FotoPerfilClick);
			// 
			// lblDica
			// 
			this.lblDica.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblDica.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.lblDica.Location = new System.Drawing.Point(201, 137);
			this.lblDica.Name = "lblDica";
			this.lblDica.Size = new System.Drawing.Size(75, 37);
			this.lblDica.TabIndex = 2;
			this.lblDica.Text = "DICA:";
			// 
			// lblTextoDica
			// 
			this.lblTextoDica.Font = new System.Drawing.Font("Yu Gothic UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTextoDica.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblTextoDica.Location = new System.Drawing.Point(272, 137);
			this.lblTextoDica.Name = "lblTextoDica";
			this.lblTextoDica.Size = new System.Drawing.Size(420, 62);
			this.lblTextoDica.TabIndex = 3;
			this.lblTextoDica.Text = "As principais matérias a serem estudadas para o Provão Paulista são: ";
			this.lblTextoDica.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// lblTextoLinguagens
			// 
			this.lblTextoLinguagens.Location = new System.Drawing.Point(213, 274);
			this.lblTextoLinguagens.Name = "lblTextoLinguagens";
			this.lblTextoLinguagens.Size = new System.Drawing.Size(213, 66);
			this.lblTextoLinguagens.TabIndex = 4;
			this.lblTextoLinguagens.Text = "Interpretação de textos, Variedades da línguam, Gêneros textuais.";
			// 
			// lblTextoMatematica
			// 
			this.lblTextoMatematica.Location = new System.Drawing.Point(490, 274);
			this.lblTextoMatematica.Name = "lblTextoMatematica";
			this.lblTextoMatematica.Size = new System.Drawing.Size(213, 48);
			this.lblTextoMatematica.TabIndex = 5;
			this.lblTextoMatematica.Text = "Conjuntos numéricos, Proporções, Funções.";
			// 
			// lblTextoCienciasNatureza
			// 
			this.lblTextoCienciasNatureza.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblTextoCienciasNatureza.Location = new System.Drawing.Point(213, 432);
			this.lblTextoCienciasNatureza.Name = "lblTextoCienciasNatureza";
			this.lblTextoCienciasNatureza.Size = new System.Drawing.Size(213, 197);
			this.lblTextoCienciasNatureza.TabIndex = 6;
			this.lblTextoCienciasNatureza.Text = "Física (mecânica, termologia/ondas, eletricidade);\r\nQuímica (estrutura da matéria" +
			", reações químicas, química no cotidiano);\r\nBiologia (ecologia, genética/evoluçã" +
			"o, corpo humano).";
			// 
			// lblCienciasNatureza
			// 
			this.lblCienciasNatureza.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCienciasNatureza.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.lblCienciasNatureza.Location = new System.Drawing.Point(213, 403);
			this.lblCienciasNatureza.Name = "lblCienciasNatureza";
			this.lblCienciasNatureza.Size = new System.Drawing.Size(272, 29);
			this.lblCienciasNatureza.TabIndex = 7;
			this.lblCienciasNatureza.Text = "Ciências da Natureza:";
			// 
			// lblLinguagens
			// 
			this.lblLinguagens.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblLinguagens.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.lblLinguagens.Location = new System.Drawing.Point(213, 240);
			this.lblLinguagens.Name = "lblLinguagens";
			this.lblLinguagens.Size = new System.Drawing.Size(183, 29);
			this.lblLinguagens.TabIndex = 8;
			this.lblLinguagens.Text = "Linguagens:";
			// 
			// lblMatematica
			// 
			this.lblMatematica.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblMatematica.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.lblMatematica.Location = new System.Drawing.Point(490, 240);
			this.lblMatematica.Name = "lblMatematica";
			this.lblMatematica.Size = new System.Drawing.Size(201, 29);
			this.lblMatematica.TabIndex = 9;
			this.lblMatematica.Text = "Matemática:";
			// 
			// lblCienciasHumanas
			// 
			this.lblCienciasHumanas.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCienciasHumanas.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.lblCienciasHumanas.Location = new System.Drawing.Point(490, 403);
			this.lblCienciasHumanas.Name = "lblCienciasHumanas";
			this.lblCienciasHumanas.Size = new System.Drawing.Size(213, 29);
			this.lblCienciasHumanas.TabIndex = 10;
			this.lblCienciasHumanas.Text = "Ciências Humanas:";
			// 
			// lblTextoCienciasHumanas
			// 
			this.lblTextoCienciasHumanas.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblTextoCienciasHumanas.Location = new System.Drawing.Point(490, 432);
			this.lblTextoCienciasHumanas.Name = "lblTextoCienciasHumanas";
			this.lblTextoCienciasHumanas.Size = new System.Drawing.Size(213, 197);
			this.lblTextoCienciasHumanas.TabIndex = 11;
			this.lblTextoCienciasHumanas.Text = "História (Antiguidade, Modernidade, Brasil)\r\nGeografia (física, geopolítica, meio" +
			" ambiente)\r\nSociologia (cultura, trabalho/economia, cidadania)\r\nFilosofia (antig" +
			"a, moderna, ética/política)";
			// 
			// FormHome
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.ClientSize = new System.Drawing.Size(753, 678);
			this.Controls.Add(this.lblTextoCienciasHumanas);
			this.Controls.Add(this.lblCienciasHumanas);
			this.Controls.Add(this.lblMatematica);
			this.Controls.Add(this.lblLinguagens);
			this.Controls.Add(this.lblCienciasNatureza);
			this.Controls.Add(this.lblTextoCienciasNatureza);
			this.Controls.Add(this.lblTextoMatematica);
			this.Controls.Add(this.lblTextoLinguagens);
			this.Controls.Add(this.lblTextoDica);
			this.Controls.Add(this.lblDica);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "FormHome";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Form1";
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.FotoLogo)).EndInit();
			this.panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.FotoRanking)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.FotoQuiz)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.FotoPerfil)).EndInit();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.PictureBox FotoPerfil;
		private System.Windows.Forms.PictureBox FotoQuiz;
		private System.Windows.Forms.PictureBox FotoRanking;
		private System.Windows.Forms.Label lblPerfil;
		private System.Windows.Forms.Label lblQuiz;
		private System.Windows.Forms.Label lblRanking;
		private System.Windows.Forms.Label lblTextoCienciasHumanas;
		private System.Windows.Forms.Label lblCienciasHumanas;
		private System.Windows.Forms.Label lblMatematica;
		private System.Windows.Forms.Label lblLinguagens;
		private System.Windows.Forms.Label lblCienciasNatureza;
		private System.Windows.Forms.Label lblTextoCienciasNatureza;
		private System.Windows.Forms.Label lblTextoMatematica;
		private System.Windows.Forms.Label lblTextoLinguagens;
		private System.Windows.Forms.Label lblTextoDica;
		private System.Windows.Forms.Label lblDica;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label lblHome;
		private System.Windows.Forms.PictureBox FotoLogo;
		private System.Windows.Forms.Panel panel1;
	}
}
