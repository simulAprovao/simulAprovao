﻿/*
 * Created by SharpDevelop.
 * User: Aluno
 * Date: 29/09/2025
 * Time: 15:02
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace SimulAprovão
{
	partial class FormQuiz
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormQuiz));
			this.panel1 = new System.Windows.Forms.Panel();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.lblTextoE = new System.Windows.Forms.Label();
			this.lblTextoD = new System.Windows.Forms.Label();
			this.lblTextoC = new System.Windows.Forms.Label();
			this.lblTextoB = new System.Windows.Forms.Label();
			this.lblTextoA = new System.Windows.Forms.Label();
			this.btnAlternativaE = new System.Windows.Forms.Button();
			this.btnAlternativaD = new System.Windows.Forms.Button();
			this.btnAlternativaC = new System.Windows.Forms.Button();
			this.btnAlternativaB = new System.Windows.Forms.Button();
			this.btnAlternativaA = new System.Windows.Forms.Button();
			this.lblPergunta = new System.Windows.Forms.Label();
			this.btnPaginaInicial = new System.Windows.Forms.Button();
			this.btnFinalizar = new System.Windows.Forms.Button();
			this.lblPontos = new System.Windows.Forms.Label();
			this.btnReiniciar = new System.Windows.Forms.Button();
			this.btnPergunta8 = new System.Windows.Forms.Button();
			this.btnPergunta1 = new System.Windows.Forms.Button();
			this.btnPergunta2 = new System.Windows.Forms.Button();
			this.btnPergunta3 = new System.Windows.Forms.Button();
			this.btnPergunta4 = new System.Windows.Forms.Button();
			this.btnPergunta5 = new System.Windows.Forms.Button();
			this.btnPergunta6 = new System.Windows.Forms.Button();
			this.btnPergunta7 = new System.Windows.Forms.Button();
			this.btnPergunta9 = new System.Windows.Forms.Button();
			this.btnPergunta10 = new System.Windows.Forms.Button();
			this.lblTimer = new System.Windows.Forms.Label();
			this.timerQuiz = new System.Windows.Forms.Timer(this.components);
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.CornflowerBlue;
			this.panel1.Controls.Add(this.pictureBox1);
			this.panel1.Controls.Add(this.label1);
			this.panel1.ForeColor = System.Drawing.Color.White;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1126, 126);
			this.panel1.TabIndex = 0;
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(0, -17);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(177, 168);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 1;
			this.pictureBox1.TabStop = false;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(466, 23);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(261, 82);
			this.label1.TabIndex = 0;
			this.label1.Text = "QUIZ";
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.Transparent;
			this.panel2.Controls.Add(this.lblTextoE);
			this.panel2.Controls.Add(this.lblTextoD);
			this.panel2.Controls.Add(this.lblTextoC);
			this.panel2.Controls.Add(this.lblTextoB);
			this.panel2.Controls.Add(this.lblTextoA);
			this.panel2.Controls.Add(this.btnAlternativaE);
			this.panel2.Controls.Add(this.btnAlternativaD);
			this.panel2.Controls.Add(this.btnAlternativaC);
			this.panel2.Controls.Add(this.btnAlternativaB);
			this.panel2.Controls.Add(this.btnAlternativaA);
			this.panel2.Controls.Add(this.lblPergunta);
			this.panel2.Location = new System.Drawing.Point(106, 218);
			this.panel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(900, 451);
			this.panel2.TabIndex = 1;
			// 
			// lblTextoE
			// 
			this.lblTextoE.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTextoE.Location = new System.Drawing.Point(111, 391);
			this.lblTextoE.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblTextoE.Name = "lblTextoE";
			this.lblTextoE.Size = new System.Drawing.Size(784, 34);
			this.lblTextoE.TabIndex = 10;
			this.lblTextoE.Text = "?";
			// 
			// lblTextoD
			// 
			this.lblTextoD.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTextoD.Location = new System.Drawing.Point(111, 337);
			this.lblTextoD.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblTextoD.Name = "lblTextoD";
			this.lblTextoD.Size = new System.Drawing.Size(784, 34);
			this.lblTextoD.TabIndex = 9;
			this.lblTextoD.Text = "?";
			// 
			// lblTextoC
			// 
			this.lblTextoC.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTextoC.Location = new System.Drawing.Point(111, 283);
			this.lblTextoC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblTextoC.Name = "lblTextoC";
			this.lblTextoC.Size = new System.Drawing.Size(784, 34);
			this.lblTextoC.TabIndex = 8;
			this.lblTextoC.Text = "?";
			// 
			// lblTextoB
			// 
			this.lblTextoB.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTextoB.Location = new System.Drawing.Point(111, 226);
			this.lblTextoB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblTextoB.Name = "lblTextoB";
			this.lblTextoB.Size = new System.Drawing.Size(784, 34);
			this.lblTextoB.TabIndex = 7;
			this.lblTextoB.Text = "?";
			// 
			// lblTextoA
			// 
			this.lblTextoA.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTextoA.Location = new System.Drawing.Point(111, 169);
			this.lblTextoA.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblTextoA.Name = "lblTextoA";
			this.lblTextoA.Size = new System.Drawing.Size(784, 34);
			this.lblTextoA.TabIndex = 6;
			this.lblTextoA.Text = "?";
			// 
			// btnAlternativaE
			// 
			this.btnAlternativaE.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnAlternativaE.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnAlternativaE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnAlternativaE.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaE.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnAlternativaE.Location = new System.Drawing.Point(21, 389);
			this.btnAlternativaE.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnAlternativaE.Name = "btnAlternativaE";
			this.btnAlternativaE.Size = new System.Drawing.Size(62, 35);
			this.btnAlternativaE.TabIndex = 5;
			this.btnAlternativaE.Text = "E";
			this.btnAlternativaE.UseVisualStyleBackColor = false;
			this.btnAlternativaE.Click += new System.EventHandler(this.BtnAlternativaEClick);
			// 
			// btnAlternativaD
			// 
			this.btnAlternativaD.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnAlternativaD.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnAlternativaD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnAlternativaD.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaD.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnAlternativaD.Location = new System.Drawing.Point(21, 335);
			this.btnAlternativaD.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnAlternativaD.Name = "btnAlternativaD";
			this.btnAlternativaD.Size = new System.Drawing.Size(62, 35);
			this.btnAlternativaD.TabIndex = 4;
			this.btnAlternativaD.Text = "D";
			this.btnAlternativaD.UseVisualStyleBackColor = false;
			this.btnAlternativaD.Click += new System.EventHandler(this.BtnAlternativaDClick);
			// 
			// btnAlternativaC
			// 
			this.btnAlternativaC.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnAlternativaC.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnAlternativaC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnAlternativaC.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaC.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnAlternativaC.Location = new System.Drawing.Point(21, 282);
			this.btnAlternativaC.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnAlternativaC.Name = "btnAlternativaC";
			this.btnAlternativaC.Size = new System.Drawing.Size(62, 35);
			this.btnAlternativaC.TabIndex = 3;
			this.btnAlternativaC.Text = "C";
			this.btnAlternativaC.UseVisualStyleBackColor = false;
			this.btnAlternativaC.Click += new System.EventHandler(this.BtnAlternativaCClick);
			// 
			// btnAlternativaB
			// 
			this.btnAlternativaB.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnAlternativaB.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnAlternativaB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnAlternativaB.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaB.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnAlternativaB.Location = new System.Drawing.Point(21, 225);
			this.btnAlternativaB.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnAlternativaB.Name = "btnAlternativaB";
			this.btnAlternativaB.Size = new System.Drawing.Size(62, 35);
			this.btnAlternativaB.TabIndex = 2;
			this.btnAlternativaB.Text = "B";
			this.btnAlternativaB.UseVisualStyleBackColor = false;
			this.btnAlternativaB.Click += new System.EventHandler(this.BtnAlternativaBClick);
			// 
			// btnAlternativaA
			// 
			this.btnAlternativaA.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnAlternativaA.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnAlternativaA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnAlternativaA.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnAlternativaA.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnAlternativaA.Location = new System.Drawing.Point(21, 168);
			this.btnAlternativaA.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnAlternativaA.Name = "btnAlternativaA";
			this.btnAlternativaA.Size = new System.Drawing.Size(62, 35);
			this.btnAlternativaA.TabIndex = 1;
			this.btnAlternativaA.Text = "A";
			this.btnAlternativaA.UseVisualStyleBackColor = false;
			this.btnAlternativaA.Click += new System.EventHandler(this.BtnAlternativaAClick);
			// 
			// lblPergunta
			// 
			this.lblPergunta.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPergunta.Location = new System.Drawing.Point(3, 2);
			this.lblPergunta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblPergunta.Name = "lblPergunta";
			this.lblPergunta.Size = new System.Drawing.Size(896, 162);
			this.lblPergunta.TabIndex = 0;
			this.lblPergunta.Text = "Pergunta ?";
			// 
			// btnPaginaInicial
			// 
			this.btnPaginaInicial.BackColor = System.Drawing.Color.White;
			this.btnPaginaInicial.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnPaginaInicial.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPaginaInicial.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnPaginaInicial.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnPaginaInicial.Location = new System.Drawing.Point(408, 805);
			this.btnPaginaInicial.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnPaginaInicial.Name = "btnPaginaInicial";
			this.btnPaginaInicial.Size = new System.Drawing.Size(153, 46);
			this.btnPaginaInicial.TabIndex = 2;
			this.btnPaginaInicial.Text = "Página Inicial";
			this.btnPaginaInicial.UseVisualStyleBackColor = false;
			this.btnPaginaInicial.Click += new System.EventHandler(this.BtnPaginaInicialClick);
			// 
			// btnFinalizar
			// 
			this.btnFinalizar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnFinalizar.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnFinalizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnFinalizar.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnFinalizar.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnFinalizar.Location = new System.Drawing.Point(570, 805);
			this.btnFinalizar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnFinalizar.Name = "btnFinalizar";
			this.btnFinalizar.Size = new System.Drawing.Size(158, 48);
			this.btnFinalizar.TabIndex = 5;
			this.btnFinalizar.Text = "Finalizar";
			this.btnFinalizar.UseVisualStyleBackColor = false;
			this.btnFinalizar.Click += new System.EventHandler(this.BtnFinalizarClick);
			// 
			// lblPontos
			// 
			this.lblPontos.BackColor = System.Drawing.Color.Transparent;
			this.lblPontos.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPontos.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.lblPontos.Location = new System.Drawing.Point(262, 751);
			this.lblPontos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblPontos.Name = "lblPontos";
			this.lblPontos.Size = new System.Drawing.Size(150, 35);
			this.lblPontos.TabIndex = 6;
			this.lblPontos.Text = "Pontos: 000";
			// 
			// btnReiniciar
			// 
			this.btnReiniciar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnReiniciar.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnReiniciar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnReiniciar.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnReiniciar.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnReiniciar.Location = new System.Drawing.Point(756, 748);
			this.btnReiniciar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnReiniciar.Name = "btnReiniciar";
			this.btnReiniciar.Size = new System.Drawing.Size(112, 35);
			this.btnReiniciar.TabIndex = 7;
			this.btnReiniciar.Text = "Reiniciar";
			this.btnReiniciar.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			this.btnReiniciar.UseVisualStyleBackColor = false;
			this.btnReiniciar.Click += new System.EventHandler(this.BtnReiniciarClick);
			// 
			// btnPergunta8
			// 
			this.btnPergunta8.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnPergunta8.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPergunta8.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnPergunta8.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta8.Location = new System.Drawing.Point(693, 692);
			this.btnPergunta8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnPergunta8.Name = "btnPergunta8";
			this.btnPergunta8.Size = new System.Drawing.Size(52, 35);
			this.btnPergunta8.TabIndex = 17;
			this.btnPergunta8.Text = "8";
			this.btnPergunta8.UseVisualStyleBackColor = false;
			this.btnPergunta8.Click += new System.EventHandler(this.BtnPergunta8Click);
			// 
			// btnPergunta1
			// 
			this.btnPergunta1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnPergunta1.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPergunta1.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnPergunta1.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta1.Location = new System.Drawing.Point(262, 692);
			this.btnPergunta1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnPergunta1.Name = "btnPergunta1";
			this.btnPergunta1.Size = new System.Drawing.Size(52, 35);
			this.btnPergunta1.TabIndex = 18;
			this.btnPergunta1.Text = "1";
			this.btnPergunta1.UseVisualStyleBackColor = false;
			this.btnPergunta1.Click += new System.EventHandler(this.BtnPergunta1Click);
			// 
			// btnPergunta2
			// 
			this.btnPergunta2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnPergunta2.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPergunta2.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnPergunta2.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta2.Location = new System.Drawing.Point(324, 692);
			this.btnPergunta2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnPergunta2.Name = "btnPergunta2";
			this.btnPergunta2.Size = new System.Drawing.Size(52, 35);
			this.btnPergunta2.TabIndex = 19;
			this.btnPergunta2.Text = "2";
			this.btnPergunta2.UseVisualStyleBackColor = false;
			this.btnPergunta2.Click += new System.EventHandler(this.BtnPergunta2Click);
			// 
			// btnPergunta3
			// 
			this.btnPergunta3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnPergunta3.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPergunta3.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnPergunta3.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta3.Location = new System.Drawing.Point(386, 692);
			this.btnPergunta3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnPergunta3.Name = "btnPergunta3";
			this.btnPergunta3.Size = new System.Drawing.Size(52, 35);
			this.btnPergunta3.TabIndex = 20;
			this.btnPergunta3.Text = "3";
			this.btnPergunta3.UseVisualStyleBackColor = false;
			this.btnPergunta3.Click += new System.EventHandler(this.BtnPergunta3Click);
			// 
			// btnPergunta4
			// 
			this.btnPergunta4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnPergunta4.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPergunta4.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnPergunta4.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta4.Location = new System.Drawing.Point(447, 692);
			this.btnPergunta4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnPergunta4.Name = "btnPergunta4";
			this.btnPergunta4.Size = new System.Drawing.Size(52, 35);
			this.btnPergunta4.TabIndex = 21;
			this.btnPergunta4.Text = "4";
			this.btnPergunta4.UseVisualStyleBackColor = false;
			this.btnPergunta4.Click += new System.EventHandler(this.BtnPergunta4Click);
			// 
			// btnPergunta5
			// 
			this.btnPergunta5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnPergunta5.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPergunta5.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnPergunta5.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta5.Location = new System.Drawing.Point(508, 692);
			this.btnPergunta5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnPergunta5.Name = "btnPergunta5";
			this.btnPergunta5.Size = new System.Drawing.Size(52, 35);
			this.btnPergunta5.TabIndex = 22;
			this.btnPergunta5.Text = "5";
			this.btnPergunta5.UseVisualStyleBackColor = false;
			this.btnPergunta5.Click += new System.EventHandler(this.BtnPergunta5Click);
			// 
			// btnPergunta6
			// 
			this.btnPergunta6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnPergunta6.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPergunta6.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnPergunta6.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta6.Location = new System.Drawing.Point(570, 692);
			this.btnPergunta6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnPergunta6.Name = "btnPergunta6";
			this.btnPergunta6.Size = new System.Drawing.Size(52, 35);
			this.btnPergunta6.TabIndex = 23;
			this.btnPergunta6.Text = "6";
			this.btnPergunta6.UseVisualStyleBackColor = false;
			this.btnPergunta6.Click += new System.EventHandler(this.BtnPergunta6Click);
			// 
			// btnPergunta7
			// 
			this.btnPergunta7.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnPergunta7.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPergunta7.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnPergunta7.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta7.Location = new System.Drawing.Point(632, 692);
			this.btnPergunta7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnPergunta7.Name = "btnPergunta7";
			this.btnPergunta7.Size = new System.Drawing.Size(52, 35);
			this.btnPergunta7.TabIndex = 24;
			this.btnPergunta7.Text = "7";
			this.btnPergunta7.UseVisualStyleBackColor = false;
			this.btnPergunta7.Click += new System.EventHandler(this.BtnPergunta7Click);
			// 
			// btnPergunta9
			// 
			this.btnPergunta9.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnPergunta9.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPergunta9.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnPergunta9.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta9.Location = new System.Drawing.Point(754, 692);
			this.btnPergunta9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnPergunta9.Name = "btnPergunta9";
			this.btnPergunta9.Size = new System.Drawing.Size(52, 35);
			this.btnPergunta9.TabIndex = 25;
			this.btnPergunta9.Text = "9";
			this.btnPergunta9.UseVisualStyleBackColor = false;
			this.btnPergunta9.Click += new System.EventHandler(this.BtnPergunta9Click);
			// 
			// btnPergunta10
			// 
			this.btnPergunta10.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.btnPergunta10.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnPergunta10.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnPergunta10.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.btnPergunta10.Location = new System.Drawing.Point(816, 692);
			this.btnPergunta10.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnPergunta10.Name = "btnPergunta10";
			this.btnPergunta10.Size = new System.Drawing.Size(52, 35);
			this.btnPergunta10.TabIndex = 26;
			this.btnPergunta10.Text = "10";
			this.btnPergunta10.UseVisualStyleBackColor = false;
			this.btnPergunta10.Click += new System.EventHandler(this.BtnPergunta10Click);
			// 
			// lblTimer
			// 
			this.lblTimer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblTimer.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTimer.ForeColor = System.Drawing.Color.CornflowerBlue;
			this.lblTimer.Location = new System.Drawing.Point(482, 151);
			this.lblTimer.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblTimer.Name = "lblTimer";
			this.lblTimer.Size = new System.Drawing.Size(155, 45);
			this.lblTimer.TabIndex = 27;
			this.lblTimer.Text = "00:00:00";
			this.lblTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// timerQuiz
			// 
			this.timerQuiz.Enabled = true;
			this.timerQuiz.Interval = 1000;
			this.timerQuiz.Tick += new System.EventHandler(this.TimerQuizTick);
			// 
			// FormQuiz
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.ClientSize = new System.Drawing.Size(1125, 883);
			this.Controls.Add(this.lblTimer);
			this.Controls.Add(this.btnPergunta10);
			this.Controls.Add(this.btnPergunta9);
			this.Controls.Add(this.btnPergunta7);
			this.Controls.Add(this.btnPergunta6);
			this.Controls.Add(this.btnPergunta5);
			this.Controls.Add(this.btnPergunta4);
			this.Controls.Add(this.btnPergunta3);
			this.Controls.Add(this.btnPergunta2);
			this.Controls.Add(this.btnPergunta1);
			this.Controls.Add(this.btnPergunta8);
			this.Controls.Add(this.btnReiniciar);
			this.Controls.Add(this.lblPontos);
			this.Controls.Add(this.btnFinalizar);
			this.Controls.Add(this.btnPaginaInicial);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.DoubleBuffered = true;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "FormQuiz";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Quiz";
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Timer timerQuiz;
		private System.Windows.Forms.Label lblTimer;
		private System.Windows.Forms.Button btnPergunta10;
		private System.Windows.Forms.Button btnPergunta8;
		private System.Windows.Forms.Button btnPergunta9;
		private System.Windows.Forms.Button btnPergunta7;
		private System.Windows.Forms.Button btnPergunta6;
		private System.Windows.Forms.Button btnPergunta5;
		private System.Windows.Forms.Button btnPergunta4;
		private System.Windows.Forms.Button btnPergunta3;
		private System.Windows.Forms.Button btnPergunta2;
		private System.Windows.Forms.Button btnPergunta1;
		private System.Windows.Forms.Button btnReiniciar;
		private System.Windows.Forms.Label lblPontos;
		private System.Windows.Forms.Button btnFinalizar;
		private System.Windows.Forms.Button btnPaginaInicial;
		private System.Windows.Forms.Label lblTextoE;
		private System.Windows.Forms.Label lblPergunta;
		private System.Windows.Forms.Button btnAlternativaA;
		private System.Windows.Forms.Button btnAlternativaB;
		private System.Windows.Forms.Button btnAlternativaC;
		private System.Windows.Forms.Button btnAlternativaD;
		private System.Windows.Forms.Button btnAlternativaE;
		private System.Windows.Forms.Label lblTextoA;
		private System.Windows.Forms.Label lblTextoB;
		private System.Windows.Forms.Label lblTextoC;
		private System.Windows.Forms.Label lblTextoD;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Panel panel1;
	}
}
