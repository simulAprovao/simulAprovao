﻿/*
 * Created by SharpDevelop.
 * User: Aluno
 * Date: 29/09/2025
 * Time: 15:08
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.IO;

namespace SimulAprovão
{
	/// <summary>
	/// Description of Ranking.
	/// </summary>
	public partial class FormRanking : Form
	{
		string nomeAtual;
		public FormRanking(string nome)
		{
		
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			CarregarRanking();
			nomeAtual = nome;
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		private void CarregarRanking()
        {
            try
		   	{
		       	string caminhoArquivo = "ranking.txt";
		       	List<Usuario> usuarios = new List<Usuario>();
		       	if (File.Exists(caminhoArquivo))
		       	{
		          	string[] linhas = File.ReadAllLines(caminhoArquivo);
                    foreach (string linha in linhas)
                    {
                        string[] dados = linha.Split(';');
                        if (dados.Length >= 2)
                        {
                            usuarios.Add(new Usuario
                            {
                                Nome = dados[0],
                                Pontuacao = int.Parse(dados[1])
                            });
                        }
                    }

                    // Ordenar por pontuação (maior primeiro)
                    usuarios.Sort((x, y) => y.Pontuacao.CompareTo(x.Pontuacao));

                    // Exibir no ListBox ou DataGridView
                    listBoxRanking.Items.Clear();
                    
                    for (int i = 0; i < usuarios.Count; i++)
                    {
                        string posicao = (i + 1).ToString();
                       	string item = string.Format("{0}º - {1} - {2} pontos", posicao, usuarios[i].Nome, usuarios[i].Pontuacao);
                        listBoxRanking.Items.Add(item);
                    }
                }
                else
                {
                    listBoxRanking.Items.Add("Ranking vazio - Jogue para aparecer aqui!");
         			listBoxRanking.Items.Add("");
           			listBoxRanking.Items.Add("Dica: Finalize um simulado para entrar no ranking!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar ranking: " + ex.Message);
            }
        }

        // Método para adicionar/atualizar usuário (chame isso quando terminar um simulado)
        public static void AtualizarPontuacao(string nome, int pontuacao)
        {
            try
            {
                string caminhoArquivo = "ranking.txt";
                List<Usuario> usuarios = new List<Usuario>();
                bool usuarioEncontrado = false;

                // Ler usuários existentes
                if (File.Exists(caminhoArquivo))
		        {
		            string[] linhas = File.ReadAllLines(caminhoArquivo);
		            foreach (string linha in linhas)
		            {
		                string[] dados = linha.Split(';');
		                if (dados.Length >= 2)
		                {
		                    if (dados[0] == nome)
		                    {
		                        int pontuacaoAntiga = int.Parse(dados[1]);
		                        if (pontuacao > pontuacaoAntiga)
		                        {
		                            usuarios.Add(new Usuario { Nome = nome, Pontuacao = pontuacao });
		                        }
		                        else
		                        {
		                            usuarios.Add(new Usuario { Nome = nome, Pontuacao = pontuacaoAntiga });
		                        }
		                        usuarioEncontrado = true;
		                    }
		                    else
		                    {
		                        usuarios.Add(new Usuario { Nome = dados[0], Pontuacao = int.Parse(dados[1]) });
		                    }
		                }
		            }
		        }
		
		        if (!usuarioEncontrado)
		        {
		            usuarios.Add(new Usuario { Nome = nome, Pontuacao = pontuacao });
		        }
		
		        using (StreamWriter writer = new StreamWriter(caminhoArquivo))
		        {
		            foreach (Usuario usuario in usuarios)
		            {
		                writer.WriteLine(usuario.Nome + ";" + usuario.Pontuacao);
		            }
		        }
		    }
            
		    catch (Exception ex)
		    {
		        MessageBox.Show("Erro ao atualizar pontuação: " + ex.Message);
		    }
        }
		
		void BtnAtualizarClick(object sender, EventArgs e)
		{
			CarregarRanking();
		}
       
       void BtnClick(object sender, EventArgs e)
       {
			FormHome home = new FormHome(nomeAtual);
			home.Show();
			this.Hide();       	
       }
	}
	
	 public class Usuario
    {
        public string Nome { get; set; }
        public int Pontuacao { get; set; }
    }
}
