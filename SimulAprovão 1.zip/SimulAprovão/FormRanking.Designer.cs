﻿/*
 * Created by SharpDevelop.
 * User: Aluno
 * Date: 29/09/2025
 * Time: 15:08
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace SimulAprovão
{
   partial class FormRanking
   {
       private System.ComponentModel.IContainer components = null;
       private System.Windows.Forms.Button btnAtualizar;
       private System.Windows.Forms.Panel panel1;
       private System.Windows.Forms.Label label1;
       private System.Windows.Forms.PictureBox pictureBox1;
       private System.Windows.Forms.ListBox listBoxRanking;
       protected override void Dispose(bool disposing)
       {
           if (disposing && (components != null))
           {
               components.Dispose();
           }
           base.Dispose(disposing);
       }
       private void InitializeComponent()
       {
       	System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormRanking));
       	this.btnAtualizar = new System.Windows.Forms.Button();
       	this.panel1 = new System.Windows.Forms.Panel();
       	this.label1 = new System.Windows.Forms.Label();
       	this.pictureBox1 = new System.Windows.Forms.PictureBox();
       	this.listBoxRanking = new System.Windows.Forms.ListBox();
       	this.btnTelaInicial = new System.Windows.Forms.Button();
       	this.panel1.SuspendLayout();
       	((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
       	this.SuspendLayout();
       	// 
       	// btnAtualizar
       	// 
       	this.btnAtualizar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
       	this.btnAtualizar.FlatAppearance.BorderSize = 2;
       	this.btnAtualizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
       	this.btnAtualizar.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
       	this.btnAtualizar.ForeColor = System.Drawing.Color.CornflowerBlue;
       	this.btnAtualizar.Location = new System.Drawing.Point(303, 351);
       	this.btnAtualizar.Name = "btnAtualizar";
       	this.btnAtualizar.Size = new System.Drawing.Size(117, 48);
       	this.btnAtualizar.TabIndex = 2;
       	this.btnAtualizar.Text = "Atualizar";
       	this.btnAtualizar.UseVisualStyleBackColor = false;
       	// 
       	// panel1
       	// 
       	this.panel1.BackColor = System.Drawing.Color.CornflowerBlue;
       	this.panel1.Controls.Add(this.label1);
       	this.panel1.Controls.Add(this.pictureBox1);
       	this.panel1.Location = new System.Drawing.Point(-2, 0);
       	this.panel1.Name = "panel1";
       	this.panel1.Size = new System.Drawing.Size(529, 77);
       	this.panel1.TabIndex = 1;
       	// 
       	// label1
       	// 
       	this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold);
       	this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
       	this.label1.Location = new System.Drawing.Point(201, 28);
       	this.label1.Name = "label1";
       	this.label1.Size = new System.Drawing.Size(122, 28);
       	this.label1.TabIndex = 0;
       	this.label1.Text = "RANKING";
       	// 
       	// pictureBox1
       	// 
       	this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
       	this.pictureBox1.Location = new System.Drawing.Point(0, -20);
       	this.pictureBox1.Name = "pictureBox1";
       	this.pictureBox1.Size = new System.Drawing.Size(106, 121);
       	this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
       	this.pictureBox1.TabIndex = 1;
       	this.pictureBox1.TabStop = false;
       	// 
       	// listBoxRanking
       	// 
       	this.listBoxRanking.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
       	this.listBoxRanking.ForeColor = System.Drawing.Color.CornflowerBlue;
       	this.listBoxRanking.ItemHeight = 24;
       	this.listBoxRanking.Location = new System.Drawing.Point(27, 91);
       	this.listBoxRanking.Name = "listBoxRanking";
       	this.listBoxRanking.Size = new System.Drawing.Size(470, 220);
       	this.listBoxRanking.TabIndex = 0;
       	// 
       	// btnTelaInicial
       	// 
       	this.btnTelaInicial.BackColor = System.Drawing.SystemColors.ButtonHighlight;
       	this.btnTelaInicial.FlatAppearance.BorderSize = 2;
       	this.btnTelaInicial.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
       	this.btnTelaInicial.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
       	this.btnTelaInicial.ForeColor = System.Drawing.Color.CornflowerBlue;
       	this.btnTelaInicial.Location = new System.Drawing.Point(93, 351);
       	this.btnTelaInicial.Name = "btnTelaInicial";
       	this.btnTelaInicial.Size = new System.Drawing.Size(117, 48);
       	this.btnTelaInicial.TabIndex = 3;
       	this.btnTelaInicial.Text = "Página Inicial";
       	this.btnTelaInicial.UseVisualStyleBackColor = false;
       	this.btnTelaInicial.Click += new System.EventHandler(this.BtnClick);
       	// 
       	// FormRanking
       	// 
       	this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
       	this.ClientSize = new System.Drawing.Size(526, 431);
       	this.Controls.Add(this.btnTelaInicial);
       	this.Controls.Add(this.listBoxRanking);
       	this.Controls.Add(this.panel1);
       	this.Controls.Add(this.btnAtualizar);
       	this.Name = "FormRanking";
       	this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
       	this.panel1.ResumeLayout(false);
       	((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
       	this.ResumeLayout(false);
       }
       private System.Windows.Forms.Button btnTelaInicial;
   }
}