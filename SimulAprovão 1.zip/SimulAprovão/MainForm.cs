﻿/*
 * Created by SharpDevelop.
 * User: Aluno
 * Date: 15/09/2025
 * Time: 15:00
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace SimulAprovão
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}	
		
		string arquivos = "usuarios.txt";
		
		void BtnCadastrarClick(object sender, EventArgs e)
		{
			string usuario = txtUsuario.Text.Trim();
			string senha = txtSenha.Text.Trim();
			
			if (usuario == "" || senha == ""){
				MessageBox.Show("Preencha todos os campos.");
			} else {
				bool cadastrado = false;
				if (File.Exists(arquivos)){
					foreach(string linha in File.ReadAllLines(arquivos)){
						string[] dados = linha.Split(';');
						if (dados[0] == usuario){
							MessageBox.Show("Usuário já cadastrado.");
							cadastrado = true;
						}
					}
				}
				
				if (cadastrado == false){
					using (StreamWriter sw = File.AppendText(arquivos)){
						sw.WriteLine(usuario + ";" + senha);
					}
					MessageBox.Show("Usuário cadastrado com sucesso.");
				}
				
			}
			
			txtSenha.Clear();
			txtUsuario.Clear();
		}
		string usuarioSalvo;
		
		void BtnAcessarClick(object sender, EventArgs e)
		{
			string usuario = txtUsuario.Text.Trim();
			string senha = txtSenha.Text.Trim();
			
			if (!File.Exists(arquivos)){
				MessageBox.Show("Nenhum usuário cadastrado.");
			}
			
			bool encontrado = false;
			foreach (string linha in File.ReadAllLines(arquivos)){
				string[] dados = linha.Split(';');
				if (dados[0] == usuario && dados[1] == senha){
					MessageBox.Show("Login realizado com sucesso.");
					MessageBox.Show("Seja bem-vindo(a), " + usuario);
					encontrado = true;
					usuarioSalvo = usuario;
				}
			}
			
			if (encontrado == false) {
				MessageBox.Show("Usuário ou senha incorretos.");
			}
			
			FormHome home = new FormHome(usuarioSalvo);
			home.Show();
			this.Hide();
		}
	}
}
