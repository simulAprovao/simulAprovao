﻿/*
 * Created by SharpDevelop.
 * User: Aluno
 * Date: 29/09/2025
 * Time: 14:20
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace SimulAprovão
{
	/// <summary>
	/// Description of Perfil.
	/// </summary>
	public partial class FormPerfil : Form
	{	
		
		private string usuarioAtual;
		
		public FormPerfil(string usuario)
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			usuarioAtual = usuario;
            CarregarDadosUsuario();
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void Button2Click(object sender, EventArgs e)
		{
			FormHome home = new FormHome(usuarioAtual);
			home.Show();
			this.Hide();
		}
		
		private void CarregarDadosUsuario()
        {
            try
            {
                txtNome.Text = usuarioAtual;
                txtNome.Enabled = false; // Não permite alterar o nome de usuário
                
                // Carrega a senha atual do arquivo
                string[] linhas = File.ReadAllLines("usuarios.txt");
                foreach (string linha in linhas)
                {
                    string[] dados = linha.Split(';');
                    if (dados.Length >= 2 && dados[0] == usuarioAtual)
                    {
                        txtSenha.Text = dados[1];
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar dados: " + ex.Message);
            }
        }
		
		void BtnSalvarClick(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(txtNovaSenha.Text))
            {
                MessageBox.Show("Digite uma nova senha!");
                return;
            }
            
            if (txtNovaSenha.Text != txtConfirmarSenha.Text)
            {
                MessageBox.Show("As senhas não coincidem!");
                return;
            }
            
            try
            {
                // Ler todos os usuários
                string[] linhas = File.ReadAllLines("usuarios.txt");
                bool usuarioEncontrado = false;
                
                using (StreamWriter writer = new StreamWriter("usuarios.txt"))
                {
                    foreach (string linha in linhas)
                    {
                        string[] dados = linha.Split(';');
                        if (dados.Length >= 2 && dados[0] == usuarioAtual)
                        {
                            // Atualiza a senha do usuário atual
                            writer.WriteLine(usuarioAtual + ";" + txtNovaSenha.Text);
                            usuarioEncontrado = true;
                        }
                        else
                        {
                            // Mantém os outros usuários
                            writer.WriteLine(linha);
                        }
                    }
                    
                    if (!usuarioEncontrado)
                    {
                        // Se não encontrou, adiciona como novo usuário
                        writer.WriteLine(usuarioAtual + ";" + txtNovaSenha.Text);
                    }
                }
                
                MessageBox.Show("Senha atualizada com sucesso!");
                txtSenha.Text = txtNovaSenha.Text;
                txtNovaSenha.Clear();
                txtConfirmarSenha.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao atualizar senha: " + ex.Message);
            }
        }			
	}
}